<?php
// include database and model files
include_once '../config/header.php';
include_once '../config/database.php';
include_once '../models/product.php';

try{
	//instantiate database and product object
	$database = new Database();
	$db = $database->getConnection();
	//initialize object
	$product = new Product($db);
	//query products
	$stmt = $product->readAll();
	$num = $stmt->rowCount();
	//check if more than 0 record is found
	if( $num > 0){
		$data = "";
		$x = 1;
		//retreive table contents
		$result = array();
		while( $row = $stmt->fetch(PDO::FETCH_ASSOC) ){
			$result[] = $row;
			/*extract($row);
			$data .= '{';
			$data .= '"id":"'.$id.'",';
			$data .= '"name":"'.$name.'",';
			$data .= '"description":"'.html_entity_decode($description).'",';
			$data .= '"price":"'.$price.'",';
			$data .= '"category_id":"'.$category_id.'",';
			$data .= '"category_name":"'.$category_name.'"';
			$data .= '}';
			$data .= $x<$num ? ',':'';
			$x++; */
		}
		//close connection
		$db = null;
		//json format output
		//echo "[{$data}]";
		echo json_encode($result);
	}
}catch(PDOException $exception){
	echo json_encode(array("error"=>$exception->getMessage()));
}
