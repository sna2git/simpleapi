<?php
// include database and model files
include_once '../config/header.php';
include_once '../config/database.php';
include_once '../models/product.php';

try{
	if( isset($_GET['_id']) ){ 
		try{
			$database = new Database();
			$db = $database->getConnection();
			$product = new Product($db);
			$stmt = $product->findOne($_GET['_id']);
			$num = $stmt->rowCount();
			$result = array();
			if( $num > 0){
				$result = $stmt->fetch(PDO::FETCH_OBJ);
			}
			//close connection
			$db = null;
			echo json_encode(array("code"=>200, "data"=>$result));
		}catch(PDOException $exception){
			echo json_encode(array("code"=>$exception->getCode(), "message"=>$exception->getMessage()));
		}
	}else{
		throw new Exception("Request not found.",404);
	} 
}catch(Exception $exception){
	echo json_encode(array("code"=>$exception->getCode(), "message"=>$exception->getMessage()));
}
