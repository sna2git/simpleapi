<?php
// include database and model files
include_once '../config/header.php';
include_once '../config/database.php';
include_once '../models/product.php';

try{
	$name = htmlentities($_POST['name'], ENT_QUOTES);
	$description = htmlentities($_POST['desc'], ENT_QUOTES);
	$price = htmlentities($_POST['price'], ENT_QUOTES);
	$category = htmlentities($_POST['category'], ENT_QUOTES);

	if( isset($_POST['edit_id']) ){ 
		$database = new Database();
		$db = $database->getConnection();
		$product = new Product($db);
		if( $_POST['edit_id'] == 0 ){
			$result = $product->save($name,$description,$price,$category);
		}else{
			//cast the product ID as an integer for security 
			$id = (int) $_POST['edit_id'];
			$result = $product->saveEdit($name,$description,$price,$category,$id);
		}
		//returns the ID of the product
		$lastid = $db->lastInsertId();
		//close connection
		$db = null;
		echo json_encode(array("code"=>$result['code'], "message"=>$result['message'], "insertid"=>$lastid));
	}else{
		throw new Exception("Request not found.",404);
	} 
}catch(Exception $exception){
	echo json_encode(array("code"=>$exception->getCode(), "message"=>$exception->getMessage()));
}