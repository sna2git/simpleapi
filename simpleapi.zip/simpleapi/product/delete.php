<?php
// include database and model files
include_once '../config/header.php';
include_once '../config/database.php';
include_once '../models/product.php';

try{
	if( isset($_GET['del_id']) ){ 
		$database = new Database();
		$db = $database->getConnection();
		$product = new Product($db);
		$result = $product->delete( (int)$_GET['del_id'] );
		//close connection
		$db = null;
		echo json_encode($result);
	}else{
		throw new Exception("Request not found.",404);
	} 
}catch(Exception $exception){
	echo json_encode(array("code"=>$exception->getCode(), "message"=>$exception->getMessage()));
}