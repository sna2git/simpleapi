<?php

class Product{
	//database connection and table name
	private $conn;
	private $table_name = "products";
	//object properties
	public $id;
	public $name;
	public $description; 
	public $price;
	public $category_id;
	public $category_name;
	public $created;
	
	//constructor with $db as database connection
	public function __construct($db){
		$this->conn = $db;
	}
	public function readAll(){
		//select all query
		$query = "SELECT c.category_name, p.id, p.name, p.description, p.price, p.category_id, p.created
					FROM 
					".$this->table_name." p
					LEFT JOIN
					categories c ON p.category_id = c.id
					ORDER BY p.created DESC ";
					
		//prepare query statement
		$stmt = $this->conn->prepare($query);
		//execute query
		$stmt->execute();
		return $stmt;
	}
	public function findOne($_id){
		//select all query
		$query = "SELECT c.category_name, p.id, p.name, p.description, p.price, p.category_id, p.created
					FROM 
					".$this->table_name." p
					LEFT JOIN
					categories c ON p.category_id = c.id 
					WHERE p.id = $_id  LIMIT 1";
		//prepare query statement
		$stmt = $this->conn->prepare($query);
		//execute query
		$stmt->execute();
		return $stmt;
	}
	public function save($name, $desc, $price, $catid ){
		try{
			//insert new product query
			$query = "INSERT INTO ".$this->table_name."
							(name, description, price,category_id, created)
							VALUES (:name, :description, :price, :category, now() )"; //:created
			//Execute the create query after binding the data
			$stmt = $this->conn->prepare($query);
			$stmt->bindParam(":name", $name, PDO::PARAM_STR); 
			$stmt->bindParam(":description", $desc, PDO::PARAM_STR);
			$stmt->bindParam(":price", $price, PDO::PARAM_STR); 
			$stmt->bindParam(":category", $catid, PDO::PARAM_INT);
			$stmt->execute();
			$stmt->closeCursor();
			return array("code"=>200, "message"=>"insert successfully");
		}catch(Exception $exception){
			return array("code"=>$exception->getCode(), "message"=>$exception->getMessage());
		}
	}
	public function saveEdit($name, $desc, $price, $catid, $editid ){
		try{
			//update product query
			$query = "UPDATE ".$this->table_name." SET
							name=:name,
							description=:description,
							price=:price,
							category_id=:category
							WHERE id=$editid";
			//Execute the edit query after binding the data
			$stmt = $this->conn->prepare($query);
			$stmt->bindParam(":name", $name, PDO::PARAM_STR);
			$stmt->bindParam(":description", $desc, PDO::PARAM_STR);
			$stmt->bindParam(":price", $price, PDO::PARAM_STR);
			$stmt->bindParam(":category", $catid, PDO::PARAM_INT);
			$stmt->execute();
			$stmt->closeCursor();
			return array("code"=>200, "message"=>"update successfully");
		}catch(Exception $exception){
			return array("code"=>$exception->getCode(), "message"=>$exception->getMessage());
		}
	}
	public function delete($delid){
		try{
			$query = "DELETE FROM ".$this->table_name." WHERE id=:id LIMIT 1";
			
			$stmt = $this->conn->prepare($query);
			$stmt->bindParam(":id", $delid, PDO::PARAM_INT);
			$stmt->execute();
			$stmt->closeCursor();
			return array("code"=>200, "message"=>"delete successfully");
		}catch(Exception $exception){
			return array("code"=>$exception->getCode(), "message"=>$exception->getMessage());
		}
	}
}