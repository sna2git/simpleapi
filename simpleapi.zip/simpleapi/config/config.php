<?php
/*$server = "localhost";//172.0.0.1
$username = "root";
$password = "";
$db = "mvc";

try{
	$handle = new PDO("mysql:host=$server; dbname=$db", "$username", "$password");
	$handle->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	echo "connected mvc in database";
}catch( PDOException $e){
		die("Oops. something weng wrong in database.");
}
*/
