<?php
// header for allowing across plateform and content-type for javascript, other...
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
